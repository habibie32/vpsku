<?php


//Ambil data cookie hanya PHPSESSID nya saja yah
//Contoh PHPSESSID=1uvt4srhvm2h5hj8ouufii7150

$useragent = "Mozilla/5.0 (Linux; Android 10; SM-N9600 Build/SAMSUNGSM-N9600; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 Mobile Safari/537.36";



$ssid_ltc = "PHPSESSID=lthm5rehfnvkmthrvnnsk736f0";

$ssid_dgb = "PHPSESSID=lijl175kkn6ce9rkpsq4lgtns7";

$ssid_trx = "PHPSESSID=jmsjb1tso6jm2icv39iu979sc0";

$ssid_doge = "PHPSESSID=7ao84gb3e4l9kb9526rdsh3jb7";

$ssid_btc = "PHPSESSID=olicc1b6hfgbjnkm3ndbrr6c76";
