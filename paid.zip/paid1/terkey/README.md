![Terkey Termux Key](screenshot.jpg)

# Terkey
Is a tool for add keys to your Termux app.

## How to install

* `$ pkg update && pkg upgrade`
* `$ pkg install python`
* `$ pkg install git`
* `$ git clone https://github.com/karjok/terkey`
* `$ cd terkey`
* `$ python terkey.py`


Or you can just copy code bellow and paste to your Termux app and of course, press enter !

```pkg update && pkg upgrade;pkg install python git;git clone https://github.com/karjok/terkey;cd terkey;python terkey.py```

## How to use?
In latest update, i made this tool with userfriendly interface, so you can follow the menu.

## Feature !

As you can see in inage above, Terkey has 3 menu,

1. Use Default Keys
1. Custom Keys
1. About

#### 1. Default Keys
If you choose this option, the program will makes
`ESC,/,-,HOME,UP,END,PGUP,TAB,CTRL,ALT,LEFT,DOWN,RIGHT,PGDN`
as your Termux key.

#### 2. Custom keys
Yeah, in latest update, i add this usefull feature. You can custom your own keys.
You just sparating your keys with comma, like `ESC,CTRL,HOME,UP,RIGHT,{,},(,)` etc.

All Termux key available in this [Termux Wiki](https://wiki.termux.com/wiki/Touch_Keyboard)

#### 3. About
Hmm.. this menu just contains a little shit about this tool and me

> Hey, if you think this is very useful, give me star please !
> Thanks !
## Author
So many information about me in internet, just type ['Karjok Pangesty'](https://t.me/om_karjok) in your browser !
