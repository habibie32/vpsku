<?php 
$user = array();
$user [] = 'habibie';

	/*   irkop   */
$pass = array();
$pass [] = 'Vina210493';
