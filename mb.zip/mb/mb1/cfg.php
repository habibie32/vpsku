<?php

$useragent = "Mozilla/5.0 (Linux; Android 11; Infinix X689 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.87 Mobile Safari/537.36";

$cookie = "ci_session=5a05eee0828a2be5f73cc93725d6989e1097094c;csrf_cookie_name=12551aed78ebf272890b302d63b4dbaf";
//jangan di rubah yg ini
$web = "coinmb.com";