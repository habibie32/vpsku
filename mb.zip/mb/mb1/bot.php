<?php
@error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));



date_default_timezone_set('Europe/Istanbul');


include "cfg.php";


error_reporting(0);
system ("clear");
set_time_limit(0);
// color
$green = "\e[1;32m";
$blockglow = "\033[102m";
$blue = "\e[1;34m";
$blockblue = "\033[104m";
$red = "\e[1;31m";
$blockred = "\033[101m";
$blockpink = "\033[105m";
$white = "\33[37;1m";
$blockwhite = "\033[107m";
$yellow = "\e[1;33m";
$blockyellow = "\033[103m";
$cyan = "\e[1;36m";
$blockcyan = "\033[106m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockgray = "\033[100m";
$orange = "\033[38;5;202m";
$end = "\033[0m";
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$res="\033[7m";
$hitam="\033[0;30m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
$lblue="\033[0;36m";
$lblue2="\033[1;36m";
$abu = "\033[0;90m";

system ("clear");
sleep(1);
echo$putih2."Loading Script ".$kuning2."[".$cyan1."0%".$kuning2."]";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."7%".$kuning2."]".$orange."█";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."33%".$kuning2."]".$orange."███████";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."66%".$kuning2."]".$orange."█████████████";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."99%".$kuning2."]".$orange."███████████████████";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."100%".$kuning2."]".$orange."████████████████████";
sleep(1);
system('clear');
sleep(1);
echo $banner = "

\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";

sleep(2);
echo$yellow2."        MARI KITA SEROK COINNYA BRAY!\n";
sleep(5);
system('clear');

//banner
echo "\033[0;36m";
system("toilet -f wideterm -F border '        MARI KITA SEROK       '");
echo "
\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
echo "\033[0;36m🔹Creator : N5-STUDIO\n";
echo "\033[0;36m🔹G.Tele  : https://t.me/n5official\n";
echo "\033[0;36m🔹Web     : https://coinmb.com\n";
echo "\033[0;36m🔹Suport  : yzzztv + all fuction indonesia\n";
echo "\033[0;36m🔹Suport  : Mr.Badut\n";
echo "\033[0;36m🔹Suport  : Allah Swt \n";
echo "\033[0;36m🔹Suport  : Keluargaku dan anak2 ku \n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

$uapw = array(
"Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36");



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://controlc.com/42550a6d");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$result = curl_exec($ch);
$linkpw = explode('link:', $result);
$linkpw1 = explode('&amp;lt;=', $linkpw[1]);
$linkpw2 = "$linkpw1[0]";
$linkpw3 = explode('linkpw:', $result);
$linkpw4 = explode('&amp;lt;=', $linkpw3[1]);
$linkpw5 = "$linkpw4[0]";
if($linkpw5 <= null){
echo "\033[1;36mTIDAK DAPAT NYAMBUNG \n";
exit;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $linkpw5);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");

$result = curl_exec($ch);
$pas = explode("<title>pw:", $result);
$pass = explode("&amp;lt;=", $pas[1]);
$password = "$pass[0]";
$read = file_get_contents("key.txt");
if($read == $password){
system("xdg-open https://youtube.com/channel/UCJDZ58BBWQyxGqbSxYzNGig");
 echo"\033[0;92m🔹Scrip ini Gratis dan tidak di perjualbelikan \n";
 echo"\033[0;92m🔹Akun terbaned bukan kesalahan Kami \n";
 echo"\033[0;92m🔹Gunakanlah dengan bijak \n";
 echo"\033[0;92m🔹™N5-STUDIO \n";
 echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
}else{
echo"\033[1;37mLINK PASSWORD: $linkpw2 \n";
$pw=readline("\033[1;36mPASSWORD : ");
file_put_contents("key.txt", $pw);
if($pw == $password){
 echo "\033[1;36mPASSWORD ✓ \n";
 echo "\033[1;36mJALANKAN LAGI SCRIPT NYA \n";
 exit;
}else{
 echo "\033[0;31m 》PASSWORD X \n";
 exit;
}}

$uapw = array(
"Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36");



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://controlc.com/42550a6d");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$result = curl_exec($ch);
$linkpw = explode('link:', $result);
$linkpw1 = explode('&amp;lt;=', $linkpw[1]);
$linkpw2 = "$linkpw1[0]";
$linkpw3 = explode('linkpw:', $result);
$linkpw4 = explode('&amp;lt;=', $linkpw3[1]);
$linkpw5 = "$linkpw4[0]";
if($linkpw5 <= null){
echo "\033[1;36mTIDAK DAPAT NYAMBUNG \n";
exit;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $linkpw5);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");

$result = curl_exec($ch);
$pas = explode("<title>pw:", $result);
$pass = explode("&amp;lt;=", $pas[1]);
$password = "$pass[0]";
$read = file_get_contents("key.txt");
if($read == $password){
system("xdg-open https://youtube.com/channel/UCJDZ58BBWQyxGqbSxYzNGig");
}else{
echo"\033[1;36mLINK PASSWORD: $linkpw2 \n";
$pw=readline("\033[1;36mPASSWORD : ");
file_put_contents("key.txt", $pw);
if($pw == $password){
 echo "\033[1;36mPASSWORD ✔️\n";
 echo "\033[1;36mJALANKAN LAGI SCRIPT NYA \n";
 exit;
}else{
 echo "\033[0;31m 》PASSWORD X \n";
 exit;
}}
//color
$hijau = "\33[0;32m";
$hijau1 = "\33[32;1m";
$hijau2 = "\e[1;32m";
$biru = "\33[0;36m";
$biru1 = "\33[36;1m";
$biru2 = "\e[1;34m";
$merah = "\33[31;1m";
$merah2 = "\e[1;31m";
$putih2 = "\33[37;1m";
$putih1 = "\e[1;37m";
$hitam = "\33[30;1m";
$kuning = "\33[33;1m";
$kuning1 = "\33[1;33m";
$kuning2 = "\e[1;33m";
$cyan = "\e[0;36m";
$cyan1 = "\e[1;36m";
$ungu = "\e[0;35m";
$ungu2 = "\e[1;35m";
$abu =	"\e[0;33m";
$abu1 = "\e[0;37m";
$abu2 = "\e[1;30m";
include('cfg.php');
system('clear');

function Get($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

function Post($url, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "./cookie/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "./cookie/cookie.txt");
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}
echo $banner = "

\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";

sleep(2);
echo$yellow2."        MARI KITA SEROK COINNYA BRAY!\n";
sleep(5);
system('clear');

//banner
echo "\033[0;36m";
system("toilet -f wideterm -F border '        MARI KITA SEROK       '");
echo "
\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
echo "\033[0;36m🔹Creator : N5-STUDIO\n";
echo "\033[0;36m🔹G.Tele  : https://t.me/n5official\n";
echo "\033[0;36m🔹Web     : https://coinmb.com\n";
echo "\033[0;36m🔹Suport  : yzzztv + all fuction indonesia\n";
echo "\033[0;36m🔹Suport  : Mr.Badut\n";
echo "\033[0;36m🔹Suport  : Allah Swt \n";
echo "\033[0;36m🔹Suport  : Keluargaku dan anak2 ku \n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
echo"\033[0;92m🔹Scrip ini Gratis dan tidak di perjualbelikan \n";
echo"\033[0;92m🔹Akun terbaned bukan kesalahan Kami \n";
echo"\033[0;92m🔹Gunakanlah dengan bijak \n";
echo"\033[0;92m🔹™N5-STUDIO \n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
echo$blue."🔸Ready on Auto faucet....🔸\n";
echo$blue."🔸Bissmillah🔸\n\n";
sleep(2);

while(true){

$url = "https://".$web."/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$cfg = Get($url, $ua);

$url = "https://".$web."/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$putih2." Autoclaim in ".$merah."[".$kuning2.$x.$merah."] ".$putih2."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://".$web."/auto/verify";
$data = "token=$t";
$cfg = Post($link, $ua, $data);

$url = "https://".$web."/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

sleep(1);

$url = "https://".$web."/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$cookie];
$cfg2 = Get($url, $ua);
$one2 = explode('<h4 class="mb-0">',$cfg2);
$two2 = explode('</h4>',$one2[1]);
$b2 = "$two2[0]";

echo $biru."√ Finish Claim ".$putih2.":: Update Balance : {$hijau2}$b2\n";
sleep(1);
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
}