<?php

$useragent = "xxxx";

$cookie = "xxxx";
//jangan di rubah yg ini
$web = "coinmb.com";