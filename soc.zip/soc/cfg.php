<?php

$ua = "xxxxxxxx";

$Cookie = "xxxxxxx";