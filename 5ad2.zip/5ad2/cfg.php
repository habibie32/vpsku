<?php


//Ambil data cookie hanya PHPSESSID nya saja yah
//Contoh PHPSESSID=1uvt4srhvm2h5hj8ouufii7150

$useragent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36";



$ssid_ltc = "PHPSESSID=nm7kg8nvbl7oencsm1mgd0sg31";

$ssid_dgb = "PHPSESSID=k9vfegotco5ije0p5657intbd5";

$ssid_trx = "PHPSESSID=u3oo7jlajrh7b4jgfd0ihrm647";

$ssid_doge = "PHPSESSID=hh4r406i29ktga3f3huhrvhqp7";

$ssid_btc = "PHPSESSID=mgr6bhuctpee0sbvutrn0l8sf5";
