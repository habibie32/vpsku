<?php
@error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));



date_default_timezone_set('Europe/Istanbul');


include "cfg.php";


error_reporting(0);
system ("clear");
set_time_limit(0);
// color
$green = "\e[1;32m";
$blockglow = "\033[102m";
$blue = "\e[1;34m";
$blockblue = "\033[104m";
$red = "\e[1;31m";
$blockred = "\033[101m";
$blockpink = "\033[105m";
$white = "\33[37;1m";
$blockwhite = "\033[107m";
$yellow = "\e[1;33m";
$blockyellow = "\033[103m";
$cyan = "\e[1;36m";
$blockcyan = "\033[106m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockgray = "\033[100m";
$orange = "\033[38;5;202m";
$end = "\033[0m";
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$res="\033[7m";
$hitam="\033[0;30m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
$lblue="\033[0;36m";
$lblue2="\033[1;36m";
$abu = "\033[0;90m";

system ("clear");
sleep(1);
echo$putih2."Loading Script ".$kuning2."[".$cyan1."0%".$kuning2."]";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."7%".$kuning2."]".$orange."█";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."33%".$kuning2."]".$orange."███████";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."66%".$kuning2."]".$orange."█████████████";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."99%".$kuning2."]".$orange."███████████████████";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."100%".$kuning2."]".$orange."████████████████████";
sleep(1);
system('clear');
sleep(1);
echo $banner = "

\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";

sleep(2);
echo$yellow2."        MARI KITA SEROK COINNYA BRAY!\n";
sleep(5);
system('clear');

//banner
echo "\033[0;36m";
system("toilet -f wideterm -F border '        MARI KITA SEROK       '");
echo "
\033[0;36m███████╗ █████╗ ████████╗██╗  ██╗███████╗██████╗ 
\033[0;36m██╔════╝██╔══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗
\033[0;36m█████╗  ███████║   ██║   ███████║█████╗  ██████╔╝
\033[0;36m██╔══╝  ██╔══██║   ██║   ██╔══██║██╔══╝  ██╔══██╗
\033[0;36m██║     ██║  ██║   ██║██╗██║  ██║███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝   ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
echo "\033[0;36m🔹Creator : N5-STUDIO\n";
echo "\033[0;36m🔹G.Tele  : https://t.me/n5official\n";
echo "\033[0;36m🔹Web     : https://adsfamily.com\n";
echo "\033[0;36m🔹Suport  : yzzztv + all fuction indonesia\n";
echo "\033[0;36m🔹Suport  : Allah Swt \n";
echo "\033[0;36m🔹Suport  : Keluargaku dan anak2 ku \n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

$uapw = array(
"Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36");



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://controlc.com/42550a6d");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$result = curl_exec($ch);
$linkpw = explode('link:', $result);
$linkpw1 = explode('&amp;lt;=', $linkpw[1]);
$linkpw2 = "$linkpw1[0]";
$linkpw3 = explode('linkpw:', $result);
$linkpw4 = explode('&amp;lt;=', $linkpw3[1]);
$linkpw5 = "$linkpw4[0]";
if($linkpw5 <= null){
echo "\033[1;36mTIDAK DAPAT NYAMBUNG \n";
exit;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $linkpw5);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");

$result = curl_exec($ch);
$pas = explode("<title>pw:", $result);
$pass = explode("&amp;lt;=", $pas[1]);
$password = "$pass[0]";
$read = file_get_contents("key.txt");
if($read == $password){
system("xdg-open https://youtube.com/channel/UCJDZ58BBWQyxGqbSxYzNGig");
 echo"\033[0;92m🔹Scrip ini Gratis dan tidak di perjualbelikan \n";
 echo"\033[0;92m🔹Akun terbaned bukan kesalahan Kami \n";
 echo"\033[0;92m🔹Gunakanlah dengan bijak \n";
 echo"\033[0;92m🔹™N5-STUDIO \n";
 echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";
}else{
echo"\033[1;37mLINK PASSWORD: $linkpw2 \n";
$pw=readline("\033[1;36mPASSWORD : ");
file_put_contents("key.txt", $pw);
if($pw == $password){
 echo "\033[1;36mPASSWORD ✓ \n";
 echo "\033[1;36mJALANKAN LAGI SCRIPT NYA \n";
 exit;
}else{
 echo "\033[0;31m 》PASSWORD X \n";
 exit;
}}

$uapw = array(
"Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36");



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://controlc.com/42550a6d");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$result = curl_exec($ch);
$linkpw = explode('link:', $result);
$linkpw1 = explode('&amp;lt;=', $linkpw[1]);
$linkpw2 = "$linkpw1[0]";
$linkpw3 = explode('linkpw:', $result);
$linkpw4 = explode('&amp;lt;=', $linkpw3[1]);
$linkpw5 = "$linkpw4[0]";
if($linkpw5 <= null){
echo "\033[1;36mTIDAK DAPAT NYAMBUNG \n";
exit;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $linkpw5);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $uapw);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");

$result = curl_exec($ch);
$pas = explode("<title>pw:", $result);
$pass = explode("&amp;lt;=", $pas[1]);
$password = "$pass[0]";
$read = file_get_contents("key.txt");
if($read == $password){
system("xdg-open https://youtube.com/channel/UCJDZ58BBWQyxGqbSxYzNGig");
}else{
echo"\033[1;36mLINK PASSWORD: $linkpw2 \n";
$pw=readline("\033[1;36mPASSWORD : ");
file_put_contents("key.txt", $pw);
if($pw == $password){
 echo "\033[1;36mPASSWORD ✔️\n";
 echo "\033[1;36mJALANKAN LAGI SCRIPT NYA \n";
 exit;
}else{
 echo "\033[0;31m 》PASSWORD X \n";
 exit;
}}
function visit($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

function TipePost($url, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}



while(true){
  
  // LITECOIN
$url = "https://adltc.cc/surf";
$ua = ["user-agent: ".$useragent,
"cookie: __cfduid=dd7f170dc97ab1102b41d10292bda64271606529684",
"cookie: HstCfa4211943=1606529686287",
"cookie: HstCmu4211943=1606529686287",
"cookie: __dtsu=6D001606524693D25EE02E64988610ED",
"cookie: FreMe=ZmF0aGFuY2FoeWFkaQ%3D%3D",
"cookie: FreMeP=YTdmMTczYTkzNDBhMjE3YmM1ZTRkOTk2NWZkZGM0MzY%3D",
"cookie: SAreD=SAreDV",
"cookie: dom3ic8zudi28v8lr6fgphwffqoz0j6c=78ce498e-dc8b-49d9-a969-cb7b760026d5%3A3%3A1",
"cookie: 494668b4c0ef4d25bda4e75c27de2817=78ce498e-dc8b-49d9-a969-cb7b760026d5:3:1",
"cookie: _data_html=30-1_77-1",
"cookie: popcashpu=1",
"cookie: a=FSQoyQzH2QA7zbZGHMT68SiR17MSdpED",
"cookie: ".$ssid_ltc,
"cookie: HstCnv4211943=13",
"cookie: HstCns4211943=16",
"cookie: SAsurf=SAsurfVal",
"cookie: HstCla4211943=1606715050951",
"cookie: HstPn4211943=8",
"cookie: HstPt4211943=96",
"cookie: MarketGidStorage=%7B%220%22%3A%7B%7D%2C%22C359710%22%3A%7B%22page%22%3A3%2C%22time%22%3A1606715053715%7D%7D",
"cookie: token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAX8SGrgFfxIaugAGBAsAAIEzPSVxIOwjPP-keZSW5IoQ226LJ1ZDoP9cSIUb9AzHjwQBHMEUCIA0SDjDxpQrkraK-WgF_Fxp-0cY89qBgwMYX5s8BZX2YAiEA5wfJBkCDtqN85I3C8VAaYf2d96gAhRrlansQs60TquY",
"cookie: _popprepop=1"];



$cfg = visit($url, $ua);
$one = explode("Account Balance<br><b>", $cfg);
$two = explode("</b>", $one[1]);
$Bal = "$two[0]";


$one = explode('<input type="hidden" id="adsid" value="', $cfg);
$two = explode('">', $one[1]);
$id = "$two[0]";

$one = explode("Duration : <b>", $cfg);
$two = explode("</b>", $one[1]);
$time = "$two[0]";





$link = "https://adltc.cc/earndata.php";
$data = "adsids=$id";
$cfg = TipePost($link, $ua, $data);

echo $blue. "🔸Visit Ads Done LTC\n";
echo $white."🔸Update Balance : {$hijau2}$Bal\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

for($x=0; $x<$time; $x++){
	echo "\r                                             \r";
		      sleep(1);
		      echo $kuning2."Wait ".$x." 80 Seconds";
	echo "\r                                             \r";
	
}






// DIGIBYTE
$url = "https://adsdgb.com/surf";
$ua = ["user-agent: ".$useragent,
"cookie: __cfduid=dddbe17796643151e0c555769c50460171606543878",
"cookie: HstCfa4461429=1606543879539",
"cookie: HstCmu4461429=1606543879539",
"cookie: c_ref_4461429=https%3A%2F%2Fadltc.cc%2F",
"cookie: __dtsu=6D001606524693D25EE02E64988610ED",
"cookie: ".$ssid_dgb,
"cookie: HstCnv4461429=3",
"cookie: HstCns4461429=3",
"cookie: SAregister=SAregister_existed",
"cookie: FreMe=ZmF0aGFuY2FoeWFkaQ%3D%3D",
"cookie: FreMeP=YTdmMTczYTkzNDBhMjE3YmM1ZTRkOTk2NWZkZGM0MzY%3D",
"cookie: SAreD=SAreDV",
"cookie: ppu_main_eda849d2b2d7c08ce08dd74b8ca961e7=1",
"cookie: dom3ic8zudi28v8lr6fgphwffqoz0j6c=78ce498e-dc8b-49d9-a969-cb7b760026d5%3A3%3A1",
"cookie: 494668b4c0ef4d25bda4e75c27de2817=78ce498e-dc8b-49d9-a969-cb7b760026d5:3:1",
"cookie: ppu_sub_eda849d2b2d7c08ce08dd74b8ca961e7=1",
"cookie: SAsurf=SAsurfVal",
"cookie: HstCla4461429=1606715434120",
"cookie: HstPn4461429=12",
"cookie: HstPt4461429=14"];

$cfg = visit($url, $ua);

$one = explode("Account Balance<br><b>", $cfg);
$two = explode("</b>", $one[1]);
$Bal = "$two[0]";

echo $yellow."🔸Visit Ads Done DGB\n";
echo $white."🔸Update Balance : {$hijau2}$Bal\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

$one = explode('<input type="hidden" id="adsid" value="', $cfg);
$two = explode('">', $one[1]);
$id = "$two[0]";

$one = explode("Duration : <b>", $cfg);
$two = explode("</b>", $one[1]);
$time = "$two[0]";





$url = "https://adsdgb.com/earndata.php";
$data = "adsids=$id";

$cfg = TipePost($url, $ua, $data);

for($x=0; $x<$time; $x++){
	echo "\r                                             \r";
			sleep(1);
	              echo "{$hijau2}Wait {$putih2}[{$merah2}$x{$putih2}]";
	echo "\r                                             \r";
	
}




// TRX
$PHPSESSID = "h6hggbsjds6s9heleoeqhaeje7";
$url = "https://surf-trx.com/surf";
$ua = ["user-agent: ".$useragent,
"cookie: __cfduid=d7da2acbf2decdc5394e2837f57575b971606524686",
"cookie: HstCfa4448235=1606524690053",
"cookie: HstCmu4448235=1606524690053",
"cookie: __dtsu=6D001606524693D25EE02E64988610ED",
"cookie: FreMe=ZmF0aGFuY2FoeWFkaQ%3D%3D",
"cookie: FreMeP=YTdmMTczYTkzNDBhMjE3YmM1ZTRkOTk2NWZkZGM0MzY%3D",
"cookie: SAreD=SAreDV",
"cookie: 494668b4c0ef4d25bda4e75c27de2817=78ce498e-dc8b-49d9-a969-cb7b760026d5:3:1",
"cookie: dom3ic8zudi28v8lr6fgphwffqoz0j6c=78ce498e-dc8b-49d9-a969-cb7b760026d5%3A3%3A1",
"cookie: c_ref_4448235=https%3A%2F%2Fadltc.cc%2F",
"cookie: a=Fk82KrUrXeXNKlr18on7OGnoNRToaddJ",
"cookie: popcashpu=1",
"cookie: 6US=1",
"cookie: ".$ssid_trx,
"cookie: HstCnv4448235=8",
"cookie: HstCns4448235=10",
"cookie: token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAX8SEZAFfxIRkgAGBAsAAIJfMO5yIIuNQRYnlRFHSEKn02uHTVUQmvmrhTGbt1t5WwQBGMEQCIEJIeQKScdzCD8nq8AAyTRiOUIZvXbQ9wxCtEbrHBJVZAiAWYuqbzW9FKNiQxPZ4ovD1XT_GYFeqJ9vDd9-63c5N_w",
"cookie: pop_delay_651=1",
"cookie: SAsurf=SAsurfVal",
"cookie: HstCla4448235=1606714521276",
"cookie: HstPn4448235=5",
"cookie: HstPt4448235=50"];

$cfg = visit($url, $ua);

$one = explode("Account Balance<br><b>", $cfg);
$two = explode("</b>", $one[1]);
$Bal = "$two[0]";


echo $red.  "🔸Visit Ads Done TRX\n";
echo $white."🔸Update Balance : {$hijau2}$Bal\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

$one = explode('<input type="hidden" id="adsid" value="', $cfg);
$two = explode('">', $one[1]);
$id = "$two[0]";

$one = explode("Duration : <b>", $cfg);
$two = explode("</b>", $one[1]);
$time = "$two[0]";

#SURF
$url = "https://surf-trx.com/earndata.php";
$data = "adsids=$id";

$cfg = TipePost($url, $ua, $data);

for($x=0; $x<$time; $x++){
	echo "\r                                             \r";
	sleep(1);
        echo $kuning2."Wait ".$x." Seconds";
	echo "\r                                             \r";

}

$url = "https://addoge.cc/surf";
$ua = ["user-agent: ".$useragent,
"cookie: __cfduid=d4c8f35d88e9a483b3bcdc2a52229c7001606717370",
"cookie: HstCfa4198386=1606717380041",
"cookie: HstCmu4198386=1606717380041",
"cookie: c_ref_4198386=https%3A%2F%2Fwww.google.com%2F",
"cookie: __dtsu=6D001606524693D25EE02E64988610ED",
"cookie: SAregister=SAregister_existed",
"cookie: FreMe=ZmF0aGFuY2FoeWFkaQ%3D%3D",
"cookie: FreMeP=YTdmMTczYTkzNDBhMjE3YmM1ZTRkOTk2NWZkZGM0MzY%3D",
"cookie: SAreD=SAreDV",
"cookie: ".$ssid_doge,
"cookie: HstCnv4198386=4",
"cookie: HstCns4198386=5",
"cookie: a=dTpQ0vym3OVNsQT4yhoLwv0wx1qyri2r",
"cookie: 6US=1",
"cookie: token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAX8V1fAFfxXV_gAGBAsAAII_d2tYnAf0TS9YcPyd7yf4PB7OROghAaSIgscERCwFawQBGMEQCIEOyO4Fc25likbJ8v_QHnAMcaerv3bblk_7p1C8o9u9kAiAgu-gDqHRpL2ERrU5-CdGhqWNUFBZyuwFyC5Az8fyCRQ",
"cookie: _popprepop=1",
"cookie: SAsurf=SAsurfVal",
"cookie: HstCla4198386=1606776230015",
"cookie: HstPn4198386=5",
"cookie: HstPt4198386=17",
"cookie: MarketGidStorage=%7B%220%22%3A%7B%22svspr%22%3A%22https%3A%2F%2Faddoge.cc%2Flogin%22%2C%22svsds%22%3A1%2C%22TejndEEDj%22%3A%225MC7KaV7%2B%22%7D%2C%22C337415%22%3A%7B%22page%22%3A2%2C%22time%22%3A1606776230738%7D%7D"];



$cfg = visit($url, $ua);

$one = explode("Account Balance<br><b>", $cfg);
$two = explode("</b>", $one[1]);
$Bal = "$two[0]";


$one = explode('<input type="hidden" id="adsid" value="', $cfg);
$two = explode('">', $one[1]);
$id = "$two[0]";

$one = explode("Duration : <b>", $cfg);
$two = explode("</b>", $one[1]);
$time = "$two[0]";


$link = "https://addoge.cc/earndata.php";
$data = "adsids=$id";

$cfg = TipePost($link, $ua, $data);

echo $cyan."🔸Visit Ads Done DOGE\n";
echo $white."🔸Update Balance : {$hijau2}$Bal\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

for($x=0; $x<$time; $x++){
        echo "\r                                             \r";
                      sleep(1);
                      echo $kuning2."Wait ".$x." Seconds";
        echo "\r                                             \r";

}


$url = "https://surfingbtc.cc/surf";
$ua = ["user-agent: ".$useragent,
"cookie: __cfduid=d4c8f35d88e9a483b3bcdc2a52229c7001606717370",
"cookie: HstCfa4198386=1606717380041",
"cookie: HstCmu4198386=1606717380041",
"cookie: c_ref_4198386=https%3A%2F%2Fwww.google.com%2F",
"cookie: __dtsu=6D001606524693D25EE02E64988610ED",
"cookie: SAregister=SAregister_existed",
"cookie: FreMe=ZmF0aGFuY2FoeWFkaQ%3D%3D",
"cookie: FreMeP=YTdmMTczYTkzNDBhMjE3YmM1ZTRkOTk2NWZkZGM0MzY%3D",
"cookie: SAreD=SAreDV",
"cookie: ".$ssid_btc,
"cookie: HstCnv4198386=4",
"cookie: HstCns4198386=5",
"cookie: a=dTpQ0vym3OVNsQT4yhoLwv0wx1qyri2r",
"cookie: 6US=1",
"cookie: token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAX8YFeAFfxgV4gAGBAsAAICbph5bWiApnGrRFGqjSnWO4S0BOrIiYa6oU3MuIys3jwQBGMEQCIDuCQe96n3SBSRQmu5g-NxRw0-UqCjoW8vP13Ra9yBeOAiAor7sc0G6ey8eVKdhRq3KWK4V65QqCdbvKpg39n-fp8A",
"cookie: _popprepop=1",
"cookie: SAsurf=SAsurfVal",
"cookie: HstCla4198386=1606776230015",
"cookie: HstPn4198386=5",
"cookie: HstPt4198386=17",
"cookie: MarketGidStorage=%7B%220%22%3A%7B%7D%2C%22C383944%22%3A%7B%22page%22%3A2%2C%22time%22%3A1606813106496%7D%7D"];


$cfg = visit($url, $ua);

$one = explode("Account Balance<br><b>", $cfg);
$two = explode("</b>", $one[1]);
$Bal = "$two[0]";


$one = explode('<input type="hidden" id="adsid" value="', $cfg);
$two = explode('">', $one[1]);
$id = "$two[0]";

$one = explode("Duration : <b>", $cfg);
$two = explode("</b>", $one[1]);
$time = "$two[0]";


$link = "https://surfingbtc.cc/earndata.php";
$data = "adsids=$id";

$cfg = TipePost($link, $ua, $data);

echo $orange."🔸Visit Ads Done BTC\n";
echo $white."🔸Update Balance : {$hijau2}$Bal\n";
echo "\e[1;93m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;97m=\e[1;93m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;94m=\e[1;97m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;95m=\e[1;91m=\e[1;93m=\e[1;92m=\e[1;96m=\e[1;92m=\e[1;96m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;96m=\e[1;97m=\e[1;94m=\e[1;95m=\e[1;92m=\e[1;91m=\e[1;93m=\e[1;96m=\e[1;92m=\e[1;93m=\e[1;94m=\e[1;95m=\e[1;93m=\e[1;97m=\e[1;91m=\e[1;92m=\e[1;94m=\e[1;93m=\e[1;92m=\e[1;97m=\e[1;96m=\e[1;95m=\e[1;92m=\e[0m\n";

for($x=0; $x<$time; $x++){
        echo "\r                                             \r";
                      sleep(1);
                      echo $kuning2."Wait ".$x." Seconds";
        echo "\r                                             \r";

}

}