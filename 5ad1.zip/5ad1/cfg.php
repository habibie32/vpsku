<?php


//Ambil data cookie hanya PHPSESSID nya saja yah
//Contoh PHPSESSID=1uvt4srhvm2h5hj8ouufii7150

$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36";



$ssid_ltc = "PHPSESSID=fp2bgc1ipmm2080k7fll0m71t1";

$ssid_dgb = "PHPSESSID=q7lotj2k5s1512ies5vrtdlc05";

$ssid_trx = "PHPSESSID=17vjlsqqqb2tkaim5nk9h3esl1";

$ssid_doge = "PHPSESSID=psj52uprff170ih0jop0r7l5j0";

$ssid_btc = "PHPSESSID=l7hh6f3d7kp7i4plj4mqgl3g83";
